class CustomExtension {
    create(player, options) {
        console.log('Custom Extension Loaded: Player version:', player.version)
    }
}

window.Evercoast.registerExtension(new CustomExtension());