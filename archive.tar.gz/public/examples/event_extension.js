class EventExtension {
    create(player, options) {

        // list of event times and callbacks
        const events = [
            {time: 5, evt: (time) => { console.log('event 1 triggered: ', time); }},
            {time: 10, evt: (time) => { console.log('event 2 triggered: ', time); }}
        ]

        // handle firing the event and poulating any params
        const fireEvent = (idx, time) => {
            if(idx < events.length) {
                events[idx].evt(time);
            }
        }

        // fine the next event from the given time
        const nextEvent = (time) => {
            for(var i = 0; i < events.length; ++i) {
                if(events[i].time > time) {
                    return i;
                }
            }
            return -1;
        }

        // update next event to trigger then ever playback resumes
        let nextEventIdx = -1
        const playbackStart = () => {
            nextEventIdx = nextEvent(player.currentTime);
        }

        player.el.addEventListener('ec-started', playbackStart);
        player.el.addEventListener('ec-resumed', playbackStart);

        // poll 5 times per second to check if next event should be triggered
        setInterval(() => {
            const currentTime = player.currentTime;

            if(nextEventIdx >= 0 && currentTime > events[nextEventIdx].time) {
                fireEvent(nextEventIdx, currentTime);
                nextEventIdx = nextEvent(currentTime);
            }

        }, 200)
    }
}

window.Evercoast.registerExtension(new EventExtension());