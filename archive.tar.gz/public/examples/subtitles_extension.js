class SubtitlesExtension {
    _isVisible = false;

    create(player, options) {
        // set up subtiles element and style
        const subtitleElement = document.createElement('div')
        subtitleElement.style.width = '100vw'
        subtitleElement.style.zIndex = '100'
        subtitleElement.style.position = 'fixed'
        subtitleElement.style.top = '75vh'
        subtitleElement.style.color = 'white'
        subtitleElement.style.fontSize = '3em'
        subtitleElement.style.textAlign = 'center'
        subtitleElement.style.overflow = 'hidden'
        subtitleElement.style.userSelect = 'none'

        // load subtitles from file or bake in
        const subtitles = [
            [0, 'Subtitle 1, start 0s'],
            [5, 'Subtitle 2, start 5s'],
            [10, 'Subtitle 3, start 10s'],
            [20, 'Subtitle 4, start 20s'],
            [30, 'Subtitle 5, start 30s']
        ]

        // function to update element with new subtitle
        const updateSubtitle = (idx) => {
            subtitleElement.innerHTML = subtitles[idx][1]
        }

        const showControls = () => {
            if(!this._isVisible) {
                player.el.appendChild(subtitleElement)
                this._isVisible = true;
            }
        }

        const hideControls = () => {
            if(this._isVisible) {
                subtitleElement.remove()
                this._isVisible = false;
            }
        }

        // load initial subtitle
        let currentIdx = 0
        updateSubtitle(currentIdx)

        // show first subtitle when playback starts
        player.el.addEventListener('ec-started', showControls);
        player.el.addEventListener('ec-resumed', showControls);
        player.el.addEventListener('ec-xr-enabled', hideControls);

        setInterval(() => {
            const currentTime = player.currentTime;
            const prevIdx = currentIdx;

            // handle if playback seeks back
            if(currentTime < subtitles[currentIdx][0]) {
                currentIdx = 0;
            }

            // loop until on correct subtitle for time, loop incase of seeking
            while((currentIdx + 1) < subtitles.length && currentTime >= subtitles[currentIdx + 1][0]) {
                currentIdx += 1;
            }

            // update subtitle if needed
            if(currentIdx != prevIdx) {
                updateSubtitle(currentIdx);
            }
        }, 200)
    }
}

window.Evercoast.registerExtension(new SubtitlesExtension());